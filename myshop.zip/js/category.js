// توابع مخصوص صفحه دسته‌بندی

let allProducts = [];
let filteredProducts = [];
let currentFilters = {
    colors: [],
    sizes: []
};

// لود داده‌های دسته‌بندی
async function loadCategoryData() {
    const urlParams = new URLSearchParams(window.location.search);
    const categorySlug = urlParams.get('slug');
    
    if (!categorySlug) {
        window.location.href = 'categories.html';
        return;
    }
    
    try {
        // لود محصولات
        const products = await loadJSON('data/products.json');
        
        // لود دسته‌بندی‌ها
        const categories = await loadJSON('data/categories.json');
        
        // پیدا کردن دسته‌بندی فعلی
        const currentCategory = categories.find(cat => cat.slug === categorySlug);
        
        if (!currentCategory) {
            showMessage('دسته‌بندی مورد نظر یافت نشد', 'error');
            return;
        }
        
        // به‌روزرسانی عنوان و توضیحات
        document.getElementById('categoryTitle').textContent = currentCategory.title;
        document.getElementById('categoryDescription').textContent = currentCategory.description;
        
        // فیلتر محصولات بر اساس دسته‌بندی
        allProducts = products.filter(product => product.category === categorySlug);
        filteredProducts = [...allProducts];
        
        // نمایش محصولات
        displayProducts();
        
        // به‌روزرسانی تعداد محصولات
        updateProductsCount();
        
        // تنظیم فیلترها
        setupFilters();
        
    } catch (error) {
        console.error('خطا در لود داده‌های دسته‌بندی:', error);
        showMessage('خطا در بارگذاری داده‌ها', 'error');
    }
}

// نمایش محصولات
function displayProducts() {
    const container = document.getElementById('categoryProductsGrid');
    if (!container) return;
    
    container.innerHTML = '';
    
    if (filteredProducts.length === 0) {
        document.getElementById('noProductsMessage').style.display = 'block';
        return;
    }
    
    document.getElementById('noProductsMessage').style.display = 'none';
    
    filteredProducts.forEach(product => {
        const productCard = createProductCard(product);
        container.appendChild(productCard);
    });
}

// ایجاد کارت محصول برای صفحه دسته‌بندی
function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    
    card.innerHTML = `
        <a href="product.html?slug=${product.slug}">
            <div class="product-image">
                <img src="${product.images[0]}" alt="${product.title}"
                     onerror="this.src='https://via.placeholder.com/400x300?text=Product+Image'">
                ${product.isFeatured ? '<span class="product-badge">ویژه</span>' : ''}
            </div>
            <div class="product-info">
                <h3>${product.title}</h3>
                <p class="short-description">${product.shortDescription}</p>
                <ul class="product-features">
                    <li><i class="fas fa-palette"></i> ${product.colors.length} رنگ</li>
                    <li><i class="fas fa-memory"></i> ${product.sizes.length} ظرفیت</li>
                </ul>
                <div class="product-actions">
                    <a href="product.html?slug=${product.slug}" class="btn">مشاهده جزئیات</a>
                </div>
            </div>
        </a>
    `;
    
    return card;
}

// تنظیم فیلترها
function setupFilters() {
    // استخراج همه رنگ‌ها و سایزهای موجود
    const allColors = new Set();
    const allSizes = new Set();
    
    allProducts.forEach(product => {
        product.colors.forEach(color => allColors.add(color));
        product.sizes.forEach(size => allSizes.add(size));
    });
    
    // نمایش فیلتر رنگ‌ها
    const colorFiltersContainer = document.getElementById('colorFilters');
    if (colorFiltersContainer) {
        colorFiltersContainer.innerHTML = '';
        allColors.forEach(color => {
            const colorOption = document.createElement('span');
            colorOption.className = 'color-option';
            colorOption.textContent = color;
            colorOption.dataset.color = color;
            
            colorOption.addEventListener('click', () => {
                toggleFilter('colors', color);
                colorOption.classList.toggle('selected');
            });
            
            colorFiltersContainer.appendChild(colorOption);
        });
    }
    
    // نمایش فیلتر سایزها
    const sizeFiltersContainer = document.getElementById('sizeFilters');
    if (sizeFiltersContainer) {
        sizeFiltersContainer.innerHTML = '';
        allSizes.forEach(size => {
            const sizeOption = document.createElement('span');
            sizeOption.className = 'size-option';
            sizeOption.textContent = size;
            sizeOption.dataset.size = size;
            
            sizeOption.addEventListener('click', () => {
                toggleFilter('sizes', size);
                sizeOption.classList.toggle('selected');
            });
            
            sizeFiltersContainer.appendChild(sizeOption);
        });
    }
}

// تغییر فیلتر
function toggleFilter(filterType, value) {
    const index = currentFilters[filterType].indexOf(value);
    
    if (index === -1) {
        currentFilters[filterType].push(value);
    } else {
        currentFilters[filterType].splice(index, 1);
    }
    
    applyFilters();
}

// اعمال فیلترها
function applyFilters() {
    filteredProducts = allProducts.filter(product => {
        // بررسی فیلتر رنگ‌ها
        if (currentFilters.colors.length > 0) {
            const hasMatchingColor = product.colors.some(color => 
                currentFilters.colors.includes(color)
            );
            if (!hasMatchingColor) return false;
        }
        
        // بررسی فیلتر سایزها
        if (currentFilters.sizes.length > 0) {
            const hasMatchingSize = product.sizes.some(size => 
                currentFilters.sizes.includes(size)
            );
            if (!hasMatchingSize) return false;
        }
        
        return true;
    });
    
    displayProducts();
    updateProductsCount();
}

// به‌روزرسانی تعداد محصولات
function updateProductsCount() {
    const countElement = document.getElementById('productsCount');
    if (countElement) {
        countElement.textContent = `${filteredProducts.length} محصول یافت شد`;
    }
}

// مرتب‌سازی محصولات
function sortProducts() {
    const sortSelect = document.getElementById('sortSelect');
    const sortValue = sortSelect.value;
    
    switch (sortValue) {
        case 'name-asc':
            filteredProducts.sort((a, b) => a.title.localeCompare(b.title, 'fa'));
            break;
        case 'name-desc':
            filteredProducts.sort((a, b) => b.title.localeCompare(a.title, 'fa'));
            break;
        default:
            // پیش‌فرض - بر اساس id
            filteredProducts.sort((a, b) => a.id - b.id);
    }
    
    displayProducts();
}

// پاک کردن فیلترها
function clearFilters() {
    currentFilters = {
        colors: [],
        sizes: []
    };
    
    // پاک کردن انتخاب‌ها در UI
    document.querySelectorAll('.color-option.selected, .size-option.selected').forEach(el => {
        el.classList.remove('selected');
    });
    
    filteredProducts = [...allProducts];
    displayProducts();
    updateProductsCount();
}

// مقداردهی اولیه
document.addEventListener('DOMContentLoaded', loadCategoryData);