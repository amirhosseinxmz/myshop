// توابع مخصوص صفحه محصول

let currentProduct = null;
let selectedColor = null;
let selectedSize = null;
let currentImageIndex = 0;

// لود داده‌های محصول
async function loadProductData() {
    const urlParams = new URLSearchParams(window.location.search);
    const productSlug = urlParams.get('slug');
    
    if (!productSlug) {
        window.location.href = 'categories.html';
        return;
    }
    
    try {
        // لود همه محصولات
        const products = await loadJSON('data/products.json');
        
        // پیدا کردن محصول فعلی
        currentProduct = products.find(product => product.slug === productSlug);
        
        if (!currentProduct) {
            showMessage('محصول مورد نظر یافت نشد', 'error');
            setTimeout(() => {
                window.location.href = 'categories.html';
            }, 2000);
            return;
        }
        
        // نمایش محصول
        displayProduct();
        
        // نمایش محصولات مرتبط
        await loadRelatedProducts();
        
        // تنظیم مقدار اولیه برای رنگ و سایز
        if (currentProduct.colors.length > 0) {
            selectedColor = currentProduct.colors[0];
        }
        if (currentProduct.sizes.length > 0) {
            selectedSize = currentProduct.sizes[0];
        }
        
    } catch (error) {
        console.error('خطا در لود داده‌های محصول:', error);
        showMessage('خطا در بارگذاری محصول', 'error');
    }
}

// نمایش محصول
function displayProduct() {
    const container = document.getElementById('productPage');
    if (!container) return;
    
    container.innerHTML = `
        <div class="product-detail">
            <div class="product-gallery">
                <div class="product-main-image">
                    <img id="mainImage" src="${currentProduct.images[0]}" 
                         alt="${currentProduct.title}"
                         onerror="this.src='https://via.placeholder.com/600x600?text=Product+Image'">
                </div>
                <div class="product-thumbnails" id="thumbnailsContainer">
                    <!-- تصاویر کوچک در اینجا لود می‌شوند -->
                </div>
            </div>
            
            <div class="product-details">
                <h1>${currentProduct.title}</h1>
                <span class="product-category-badge">${currentProduct.category}</span>
                
                <div class="product-description">
                    <h3>توضیحات محصول</h3>
                    <p>${currentProduct.fullDescription}</p>
                </div>
                
                <div class="product-options">
                    <div class="option-group">
                        <h3>رنگ‌های موجود</h3>
                        <div class="color-options" id="colorOptions">
                            <!-- گزینه‌های رنگ در اینجا لود می‌شوند -->
                        </div>
                    </div>
                    
                    <div class="option-group">
                        <h3>حافظه‌های موجود</h3>
                        <div class="size-options" id="sizeOptions">
                            <!-- گزینه‌های سایز در اینجا لود می‌شوند -->
                        </div>
                    </div>
                </div>
                
                <div class="product-actions">
                    <a href="${currentProduct.buyLink}" target="_blank" class="btn buy-btn">
                        <i class="fas fa-shopping-cart"></i> خرید محصول
                    </a>
                    <button class="wishlist-btn" onclick="addToWishlist()">
                        <i class="fas fa-heart"></i>
                    </button>
                </div>
            </div>
        </div>
    `;
    
    // نمایش تصاویر کوچک
    displayThumbnails();
    
    // نمایش گزینه‌های رنگ
    displayColorOptions();
    
    // نمایش گزینه‌های سایز
    displaySizeOptions();
}

// نمایش تصاویر کوچک
function displayThumbnails() {
    const container = document.getElementById('thumbnailsContainer');
    if (!container) return;
    
    container.innerHTML = '';
    
    currentProduct.images.forEach((image, index) => {
        const thumbnail = document.createElement('div');
        thumbnail.className = `thumbnail ${index === 0 ? 'active' : ''}`;
        thumbnail.innerHTML = `
            <img src="${image}" alt="تصویر ${index + 1}" 
                 onerror="this.src='https://via.placeholder.com/100x100?text=Thumbnail'">
        `;
        
        thumbnail.addEventListener('click', () => {
            changeMainImage(index);
            document.querySelectorAll('.thumbnail').forEach(thumb => {
                thumb.classList.remove('active');
            });
            thumbnail.classList.add('active');
        });
        
        container.appendChild(thumbnail);
    });
}

// تغییر تصویر اصلی
function changeMainImage(index) {
    const mainImage = document.getElementById('mainImage');
    if (mainImage && currentProduct.images[index]) {
        mainImage.src = currentProduct.images[index];
        currentImageIndex = index;
    }
}

// نمایش گزینه‌های رنگ
function displayColorOptions() {
    const container = document.getElementById('colorOptions');
    if (!container) return;
    
    container.innerHTML = '';
    
    currentProduct.colors.forEach(color => {
        const colorOption = document.createElement('div');
        colorOption.className = `color-option-circle ${color === selectedColor ? 'selected' : ''}`;
        colorOption.style.backgroundColor = getColorCode(color);
        colorOption.title = color;
        colorOption.dataset.color = color;
        
        colorOption.addEventListener('click', () => {
            selectedColor = color;
            document.querySelectorAll('.color-option-circle').forEach(opt => {
                opt.classList.remove('selected');
            });
            colorOption.classList.add('selected');
            updateSelectionSummary();
        });
        
        container.appendChild(colorOption);
    });
}

// نمایش گزینه‌های سایز
function displaySizeOptions() {
    const container = document.getElementById('sizeOptions');
    if (!container) return;
    
    container.innerHTML = '';
    
    currentProduct.sizes.forEach(size => {
        const sizeOption = document.createElement('div');
        sizeOption.className = `size-option-box ${size === selectedSize ? 'selected' : ''}`;
        sizeOption.textContent = size;
        sizeOption.dataset.size = size;
        
        sizeOption.addEventListener('click', () => {
            selectedSize = size;
            document.querySelectorAll('.size-option-box').forEach(opt => {
                opt.classList.remove('selected');
            });
            sizeOption.classList.add('selected');
            updateSelectionSummary();
        });
        
        container.appendChild(sizeOption);
    });
}

// به‌روزرسانی خلاصه انتخاب‌ها
function updateSelectionSummary() {
    // در این نسخه ساده، فقط در کنسول لاگ می‌کنیم
    // در نسخه کامل می‌توان در UI نمایش داد
    console.log(`انتخاب‌ها: رنگ ${selectedColor}، سایز ${selectedSize}`);
}

// تبدیل نام رنگ به کد رنگ (ساده شده)
function getColorCode(colorName) {
    const colorMap = {
        'Black Titanium': '#1a1a1a',
        'White Titanium': '#f0f0f0',
        'Blue Titanium': '#007AFF',
        'Titanium Gray': '#8E8E93',
        'Titanium Black': '#1D1D1F',
        'Titanium Violet': '#A2845E',
        'Obsidian': '#1F1F1F',
        'Porcelain': '#F2F2F7',
        'Bay': '#0A84FF',
        'Midnight': '#171717',
        'Starlight': '#F5F5F7',
        'Silver': '#E4E4E4',
        'White': '#FFFFFF'
    };
    
    return colorMap[colorName] || '#CCCCCC';
}

// اضافه کردن به علاقه‌مندی‌ها
function addToWishlist() {
    if (!currentProduct) return;
    
    let wishlist = getFromLocalStorage('wishlist') || [];
    
    // بررسی وجود محصول در لیست
    if (!wishlist.some(item => item.id === currentProduct.id)) {
        wishlist.push({
            id: currentProduct.id,
            title: currentProduct.title,
            slug: currentProduct.slug,
            image: currentProduct.images[0],
            addedAt: new Date().toISOString()
        });
        
        saveToLocalStorage('wishlist', wishlist);
        showMessage('محصول به علاقه‌مندی‌ها اضافه شد', 'success');
    } else {
        showMessage('این محصول قبلاً به علاقه‌مندی‌ها اضافه شده', 'info');
    }
}

// لود محصولات مرتبط
async function loadRelatedProducts() {
    if (!currentProduct) return;
    
    try {
        const products = await loadJSON('data/products.json');
        
        // فیلتر محصولات مرتبط (همان دسته‌بندی، به جز خود محصول)
        const relatedProducts = products.filter(product => 
            product.category === currentProduct.category && 
            product.id !== currentProduct.id
        ).slice(0, 4); // حداکثر 4 محصول
        
        if (relatedProducts.length > 0) {
            displayRelatedProducts(relatedProducts);
        }
    } catch (error) {
        console.error('خطا در لود محصولات مرتبط:', error);
    }
}

// نمایش محصولات مرتبط
function displayRelatedProducts(products) {
    const container = document.getElementById('relatedProductsGrid');
    if (!container) return;
    
    container.innerHTML = '';
    
    products.forEach(product => {
        const productCard = createProductCard(product);
        container.appendChild(productCard);
    });
}

// ایجاد کارت محصول برای بخش مرتبط
function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    
    card.innerHTML = `
        <a href="product.html?slug=${product.slug}">
            <div class="product-image">
                <img src="${product.images[0]}" alt="${product.title}"
                     onerror="this.src='https://via.placeholder.com/400x300?text=Product+Image'">
            </div>
            <div class="product-info">
                <h3>${product.title}</h3>
                <p class="short-description">${product.shortDescription}</p>
                <ul class="product-features">
                    <li><i class="fas fa-palette"></i> ${product.colors.length} رنگ</li>
                    <li><i class="fas fa-memory"></i> ${product.sizes.length} ظرفیت</li>
                </ul>
                <div class="product-actions">
                    <a href="product.html?slug=${product.slug}" class="btn">مشاهده جزئیات</a>
                </div>
            </div>
        </a>
    `;
    
    return card;
}

// مقداردهی اولیه
document.addEventListener('DOMContentLoaded', loadProductData);