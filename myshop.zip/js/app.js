// توابع مشترک برای کل سایت

// لود هدر و فوتر
async function loadHeaderAndFooter() {
    try {
        // لود هدر
        const headerResponse = await fetch('header.html');
        const headerHTML = await headerResponse.text();
        document.getElementById('header').innerHTML = headerHTML;
        
        // لود فوتر
        const footerResponse = await fetch('footer.html');
        const footerHTML = await footerResponse.text();
        document.getElementById('footer').innerHTML = footerHTML;
        
        // اجرای اسکریپت‌های موجود در فایل‌های لود شده
        executeScriptsInHTML(headerHTML + footerHTML);
    } catch (error) {
        console.error('خطا در لود هدر یا فوتر:', error);
    }
}

// اجرای اسکریپت‌های داخل HTML لود شده
function executeScriptsInHTML(html) {
    const template = document.createElement('template');
    template.innerHTML = html;
    
    const scripts = template.content.querySelectorAll('script');
    scripts.forEach(oldScript => {
        const newScript = document.createElement('script');
        Array.from(oldScript.attributes).forEach(attr => {
            newScript.setAttribute(attr.name, attr.value);
        });
        newScript.textContent = oldScript.textContent;
        document.body.appendChild(newScript);
    });
}

// نمایش پیام
function showMessage(message, type = 'info') {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message message-${type}`;
    messageDiv.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">×</button>
    `;
    
    document.body.appendChild(messageDiv);
    
    // حذف خودکار پس از 5 ثانیه
    setTimeout(() => {
        if (messageDiv.parentElement) {
            messageDiv.remove();
        }
    }, 5000);
}

// استایل برای پیام‌ها
const messageStyles = document.createElement('style');
messageStyles.textContent = `
    .message {
        position: fixed;
        top: 100px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: var(--radius);
        color: white;
        display: flex;
        justify-content: space-between;
        align-items: center;
        min-width: 300px;
        max-width: 500px;
        box-shadow: var(--shadow-lg);
        z-index: 9999;
        animation: slideIn 0.3s ease;
    }
    
    .message-info { background-color: var(--primary-color); }
    .message-success { background-color: var(--success-color); }
    .message-warning { background-color: var(--warning-color); }
    .message-error { background-color: var(--danger-color); }
    
    .message button {
        background: none;
        border: none;
        color: white;
        font-size: 1.5rem;
        cursor: pointer;
        margin-right: 0.5rem;
    }
    
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
`;
document.head.appendChild(messageStyles);

// لود داده‌ها
async function loadJSON(filePath) {
    try {
        const response = await fetch(filePath);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error(`خطا در لود فایل ${filePath}:`, error);
        return [];
    }
}

// فرمت قیمت
function formatPrice(price) {
    return new Intl.NumberFormat('fa-IR').format(price) + ' تومان';
}

// ذخیره در localStorage
function saveToLocalStorage(key, data) {
    try {
        localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
        console.error('خطا در ذخیره localStorage:', error);
    }
}

// خواندن از localStorage
function getFromLocalStorage(key) {
    try {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    } catch (error) {
        console.error('خطا در خواندن localStorage:', error);
        return null;
    }
}

// مدیریت دسته‌بندی‌های فعال
function setActiveCategory(slug) {
    const navLinks = document.querySelectorAll('.nav-list a');
    navLinks.forEach(link => {
        link.classList.remove('active');
    });
    
    const activeLink = document.querySelector(`.nav-list a[href*="${slug}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }
}

// رویدادهای سبد خرید و علاقه‌مندی
function setupCartAndWishlist() {
    // در این نسخه ساده شده، فقط پیام نمایش می‌دهیم
    // در نسخه کامل می‌توان به localStorage وصل کرد
    document.addEventListener('click', (e) => {
        if (e.target.closest('.add-to-cart')) {
            showMessage('محصول به سبد خرید اضافه شد', 'success');
        }
        
        if (e.target.closest('.wishlist-btn')) {
            showMessage('محصول به علاقه‌مندی‌ها اضافه شد', 'info');
        }
    });
}

// مقداردهی اولیه
document.addEventListener('DOMContentLoaded', () => {
    loadHeaderAndFooter();
    setupCartAndWishlist();
    
    // تنظیم دسته‌بندی فعال بر اساس URL
    const currentPage = window.location.pathname.split('/').pop();
    if (currentPage.includes('category')) {
        const urlParams = new URLSearchParams(window.location.search);
        const slug = urlParams.get('slug');
        if (slug) {
            setActiveCategory(`slug=${slug}`);
        }
    } else {
        setActiveCategory(currentPage);
    }
});