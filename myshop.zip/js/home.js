// توابع مخصوص صفحه اصلی

let currentSlide = 0;
let sliderInterval;

// لود داده‌های صفحه اصلی
async function loadHomeData() {
    try {
        // لود محصولات
        const products = await loadJSON('data/products.json');
        
        // لود دسته‌بندی‌ها
        const categories = await loadJSON('data/categories.json');
        
        // نمایش اسلایدر
        const sliderProducts = products.filter(product => product.isSlider);
        if (sliderProducts.length > 0) {
            displaySlider(sliderProducts);
            startSlider();
        }
        
        // نمایش دسته‌بندی‌ها
        if (categories.length > 0) {
            displayCategories(categories.slice(0, 4)); // فقط 4 دسته اول
        }
        
        // نمایش محصولات ویژه
        const featuredProducts = products.filter(product => product.isFeatured);
        if (featuredProducts.length > 0) {
            displayFeaturedProducts(featuredProducts.slice(0, 4)); // فقط 4 محصول اول
        }
    } catch (error) {
        console.error('خطا در لود داده‌های صفحه اصلی:', error);
    }
}

// نمایش اسلایدر
function displaySlider(products) {
    const sliderTrack = document.getElementById('sliderTrack');
    if (!sliderTrack) return;
    
    sliderTrack.innerHTML = '';
    
    products.forEach((product, index) => {
        const slide = document.createElement('div');
        slide.className = 'slide';
        slide.innerHTML = `
            <img src="${product.images[0]}" alt="${product.title}" 
                 onerror="this.src='https://via.placeholder.com/800x400?text=Product+Image'">
            <div class="slide-content">
                <h3>${product.title}</h3>
                <p>${product.shortDescription}</p>
                <a href="product.html?slug=${product.slug}" class="btn">مشاهده جزئیات</a>
            </div>
        `;
        sliderTrack.appendChild(slide);
    });
    
    // تنظیم دکمه‌های اسلایدر
    setupSliderButtons(products.length);
}

// تنظیم دکمه‌های اسلایدر
function setupSliderButtons(totalSlides) {
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    
    if (!prevBtn || !nextBtn) return;
    
    prevBtn.addEventListener('click', () => {
        moveSlider(-1);
        resetSliderInterval();
    });
    
    nextBtn.addEventListener('click', () => {
        moveSlider(1);
        resetSliderInterval();
    });
}

// حرکت اسلایدر
function moveSlider(direction) {
    const sliderTrack = document.getElementById('sliderTrack');
    const slides = document.querySelectorAll('.slide');
    
    if (!sliderTrack || slides.length === 0) return;
    
    currentSlide = (currentSlide + direction + slides.length) % slides.length;
    sliderTrack.style.transform = `translateX(-${currentSlide * 100}%)`;
}

// شروع اسلایدر خودکار
function startSlider() {
    sliderInterval = setInterval(() => {
        moveSlider(1);
    }, 5000);
}

// ریست اینتروال اسلایدر
function resetSliderInterval() {
    clearInterval(sliderInterval);
    startSlider();
}

// نمایش دسته‌بندی‌ها
function displayCategories(categories) {
    const container = document.getElementById('categoriesGrid');
    if (!container) return;
    
    container.innerHTML = '';
    
    categories.forEach(category => {
        const categoryCard = document.createElement('a');
        categoryCard.href = `category.html?slug=${category.slug}`;
        categoryCard.className = 'category-card';
        
        categoryCard.innerHTML = `
            <div class="category-image">
                <img src="${category.image}" alt="${category.title}" 
                     onerror="this.src='https://via.placeholder.com/400x200?text=Category+Image'">
            </div>
            <div class="category-info">
                <h3>${category.title}</h3>
                <p>${category.description}</p>
                <span class="view-category">مشاهده محصولات <i class="fas fa-arrow-left"></i></span>
            </div>
        `;
        
        container.appendChild(categoryCard);
    });
}

// نمایش محصولات ویژه
function displayFeaturedProducts(products) {
    const container = document.getElementById('featuredGrid');
    if (!container) return;
    
    container.innerHTML = '';
    
    products.forEach(product => {
        const productCard = createProductCard(product);
        container.appendChild(productCard);
    });
}

// ایجاد کارت محصول
function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    
    card.innerHTML = `
        <a href="product.html?slug=${product.slug}">
            <div class="product-image">
                <img src="${product.images[0]}" alt="${product.title}"
                     onerror="this.src='https://via.placeholder.com/400x300?text=Product+Image'">
                ${product.isFeatured ? '<span class="product-badge">ویژه</span>' : ''}
            </div>
            <div class="product-info">
                <h3>${product.title}</h3>
                <p class="product-category">${getCategoryTitle(product.category)}</p>
                <p class="short-description">${product.shortDescription}</p>
                <ul class="product-features">
                    ${product.colors.map(color => `<li><i class="fas fa-circle"></i> ${color}</li>`).slice(0, 2).join('')}
                    ${product.sizes.map(size => `<li><i class="fas fa-microchip"></i> ${size}</li>`).slice(0, 1).join('')}
                </ul>
                <div class="product-actions">
                    <a href="product.html?slug=${product.slug}" class="btn">مشاهده جزئیات</a>
                </div>
            </div>
        </a>
    `;
    
    return card;
}

// دریافت عنوان دسته‌بندی
async function getCategoryTitle(slug) {
    try {
        const categories = await loadJSON('data/categories.json');
        const category = categories.find(cat => cat.slug === slug);
        return category ? category.title : slug;
    } catch (error) {
        return slug;
    }
}

// مقداردهی اولیه صفحه اصلی
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('sliderTrack')) {
        loadHomeData();
    }
});